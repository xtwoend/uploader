import './../../../node_modules/dropzone/dist/dropzone.css'
import vueDropzone from './components/vue-dropzone.vue'

export default vueDropzone
